import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.patches as mpatches
from tqdm import tqdm
from IPython.display import HTML,clear_output


class ParticleSimulation:
    """
    Class to simulate the motion of particles in a box under the influence of gravity.
    """
    def __init__(self, N_A, N_B, M_A, M_B, R, v_0, seed=None):
        """
        Initialize the simulation.

        Parameters
        ----------
        N_A : int
            Number of particles of type A.
        N_B : int
            Number of particles of type B.
        M_A : float
            Mass of particles of type A.
        M_B : float
            Mass of particles of type B.
        R : float
            Radius of the particles.
        v_0 : float
            Maximum initial velocity of the particles.
        seed : int, optional
            Random seed for reproducibility.
        """
        self.N_A = N_A
        self.N_B = N_B
        self.M_A = M_A
        self.M_B = M_B
        self.R = R
        self.v_0 = v_0
        self.g = 9.81
        self.seed = seed

        np.random.seed(seed)
        self.box_width = 8
        self.box_height = 16
        self.particles = []

        self.initialize_particles()

    def initialize_particles(self):
        """
        Initialize the positions and velocities of all particles.
        The particles are randomly distributed within the box,
        and their initial velocities are also chosen randomly.
        """
        total_particles = self.N_A + self.N_B
        positions = np.random.uniform(low=0, high=self.box_width, size=(total_particles, 2))
        positions[:, 1] = np.minimum(positions[:, 1], 8)  # Limit y position to 8

        velocities = np.random.uniform(low=-self.v_0, high=self.v_0, size=(total_particles, 2))

        for i in range(total_particles):
            if i < self.N_A:
                mass = self.M_A
                color = 'blue'
            else:
                mass = self.M_B
                color = 'red'

            particle = {
                'position': positions[i],
                'velocity': velocities[i],
                'mass': mass,
                'color': color
            }

            self.particles.append(particle)

    def evolve(self, T, dt, dt_s):
        """
        Evolve the simulation for a given time period.

        Parameters
        ----------
        T : float
            Total time to evolve the system.
        dt : float
            Time step for the evolution of the system.
        dt_s : float
            Time step for sampling the system's state.

        Returns
        -------
        tuple
            Tuple containing arrays of positions and velocities samples and average kinetic and potential energy of particles A and B.
        """
        N_steps = int(T / dt)
        N_samples = int(T / dt_s)

        positions_samples = np.zeros((N_samples, self.N_A + self.N_B, 2))
        velocities_samples = np.zeros((N_samples, self.N_A + self.N_B, 2))
        avg_kinetic_energy_A = np.zeros(N_samples)
        avg_kinetic_energy_B = np.zeros(N_samples)
        avg_potential_energy_A = np.zeros(N_samples)
        avg_potential_energy_B = np.zeros(N_samples)

        pbar = tqdm(total=N_steps)

        for step in range(N_steps):
            self.update_positions(dt)
            self.handle_collisions_with_walls()
            self.handle_collisions_between_particles()

            if step % (dt_s / dt) == 0:
                sample_index = int(step / (dt_s / dt))
                positions_samples[sample_index] = self.get_positions()
                velocities_samples[sample_index] = self.get_velocities()
                avg_kinetic_energy_A[sample_index] = self.get_average_kinetic_energy(self.N_A, self.M_A)
                avg_kinetic_energy_B[sample_index] = self.get_average_kinetic_energy(self.N_B, self.M_B)
                avg_potential_energy_A[sample_index] = self.get_average_potential_energy(self.N_A, self.M_A)
                avg_potential_energy_B[sample_index] = self.get_average_potential_energy(self.N_B, self.M_B)

            pbar.update()

        pbar.close()

        return positions_samples, velocities_samples, avg_kinetic_energy_A, avg_kinetic_energy_B, avg_potential_energy_A, avg_potential_energy_B

    def update_positions(self, dt):
        """
        Update the positions of all particles.

        Parameters
        ----------
        dt : float
            Time step for the position update.
        """
        for particle in self.particles:
            particle['position'] += particle['velocity'] * dt
            particle['position'][1] -= 0.5 * self.g * dt**2
            particle['velocity'][1] -= self.g * dt

    def handle_collisions_with_walls(self):
        """
        Handle collisions of particles with the walls of the box.
        """
        for particle in self.particles:
            x, y = particle['position']
            vx, vy = particle['velocity']

            if x - self.R < 0 or x + self.R > self.box_width:
                vx = -vx

            if y - self.R < 0 or y + self.R > self.box_height:
                vy = -vy

            particle['velocity'] = np.array([vx, vy])

    def handle_collisions_between_particles(self):
        """
        Handle collisions between particles.
        Optimized by using a more efficient collision detection algorithm.
        """
        positions = self.get_positions()
        close_pairs = self.get_close_pairs(positions)

        for i, j in close_pairs:
            if np.linalg.norm(positions[i] - positions[j]) <= 2 * self.R:
                self.handle_particle_collision(self.particles[i], self.particles[j])

    def get_close_pairs(self, positions):
        """
        Identify pairs of particles that are close to each other using a grid-based spatial partitioning method.

        Parameters
        ----------
        positions : numpy.ndarray
            Array containing the positions of the particles.

        Returns
        -------
        list of tuples
            List containing pairs of indices of particles that are close to each other.
        """
        # Size of each cell in the grid
        cell_size = 2 * self.R

        # Number of cells in each dimension
        nx = int(np.ceil(self.box_width / cell_size))
        ny = int(np.ceil(self.box_height / cell_size))

        # Initialize a 2D list to store the particles in each cell
        cells = [[[] for _ in range(ny)] for _ in range(nx)]

        # Assign each particle to a cell
        for i, position in enumerate(positions):
            cell_x = int(position[0] / cell_size)
            cell_y = int(position[1] / cell_size)
            cells[cell_x][cell_y].append(i)

        # Identify pairs of particles that are close to each other
        close_pairs = []
        for cell_x in range(nx):
            for cell_y in range(ny):
                # Get the indices of the particles in this cell
                indices = cells[cell_x][cell_y]

                # Check for collisions within this cell
                for i in range(len(indices)):
                    for j in range(i + 1, len(indices)):
                        close_pairs.append((indices[i], indices[j]))

                # Check for collisions with particles in neighboring cells
                for dx in [-1, 0, 1]:
                    for dy in [-1, 0, 1]:
                        neighbor_x = cell_x + dx
                        neighbor_y = cell_y + dy
                        if 0 <= neighbor_x < nx and 0 <= neighbor_y < ny and not (dx == 0 and dy == 0):
                            for i in indices:
                                for j in cells[neighbor_x][neighbor_y]:
                                    close_pairs.append((i, j))

        return close_pairs

    def distFast(self, pos):
        """
        Calculate the pairwise distance between points for an array of points.

        Parameters
        ----------
        pos : numpy.ndarray
            Array containing the positions of the points.

        Returns
        -------
        numpy.ndarray
            Array containing the pairwise distances.
        """
        R = np.sqrt(np.einsum('ijl->ij',(pos[:,np.newaxis,:] - pos[np.newaxis,:,:])**2.))
        return R

    def handle_particle_collision(self, particle_i, particle_j):
        """
        Handle collision between two particles.

        Parameters
        ----------
        particle_i : dict
            Dictionary containing the properties of the first particle.
        particle_j : dict
            Dictionary containing the properties of the second particle.
        """
        ri = particle_i['position']
        rj = particle_j['position']
        vi = particle_i['velocity']
        vj = particle_j['velocity']
        mi = particle_i['mass']
        mj = particle_j['mass']

        rij = ri - rj
        vij = vi - vj
        rij_dot_vij = np.dot(rij, vij)
        rij_dot_rij = np.dot(rij, rij)

        vi_prime = vi - (2 * mj * rij_dot_vij / ((mi + mj) * rij_dot_rij)) * rij
        vj_prime = vj + (2 * mi * rij_dot_vij / ((mi + mj) * rij_dot_rij)) * rij

        particle_i['velocity'] = vi_prime
        particle_j['velocity'] = vj_prime

    def get_positions(self):
        """
        Get the positions of all particles.

        Returns
        -------
        numpy.ndarray
            Array containing the positions of all particles.
        """
        return np.array([particle['position'] for particle in self.particles])

    def get_velocities(self):
        """
        Get the velocities of all particles.

        Returns
        -------
        numpy.ndarray
            Array containing the velocities of all particles.
        """
        return np.array([particle['velocity'] for particle in self.particles])

    def get_average_kinetic_energy(self, N_particles, mass):
        """
        Calculate the average kinetic energy of a set of particles.

        Parameters
        ----------
        N_particles : int
            Number of particles.
        mass : float
            Mass of the particles.

        Returns
        -------
        float
            Average kinetic energy of the particles.
        """
        velocities = np.array([p['velocity'] for p in self.particles[:N_particles]])
        total_kinetic_energy = 0.5 * mass * np.sum(velocities**2)
        return total_kinetic_energy / N_particles

    def get_average_potential_energy(self, N_particles, mass):
        """
        Calculate the average potential energy of a set of particles.

        Parameters
        ----------
        N_particles : int
            Number of particles.
        mass : float
            Mass of the particles.

        Returns
        -------
        float
            Average potential energy of the particles.
        """
        positions = np.array([p['position'][1] for p in self.particles[:N_particles]])
        total_potential_energy = mass * self.g * np.sum(positions)
        return total_potential_energy / N_particles


    def animate(self, positions_samples, interval, frame_number = 200):
        """
        Create an animation of the motion of the particles.

        Parameters
        ----------
        positions_samples : numpy.ndarray
            Array containing the positions of all particles at different time steps.
        interval : int
            Time interval between frames in the animation.
        """
        fig, ax = plt.subplots()
        ax.set_xlim(0, self.box_width)
        ax.set_ylim(0, self.box_height)

        # Initialize scatter plot with initial positions and colors
        initial_positions = positions_samples[0]
        colors = [particle['color'] for particle in self.particles]
        particles_scatter = ax.scatter(initial_positions[:, 0], initial_positions[:, 1], c=colors, s=10)

        # Add legend outside of plot
        blue_patch = mpatches.Patch(color='blue', label='Type A')
        red_patch = mpatches.Patch(color='red', label='Type B')
        ax.legend(handles=[blue_patch, red_patch], loc='center left', bbox_to_anchor=(1, 0.5))

        # Start progress bar
        pbar = tqdm(total=frame_number)

        def update(frame):
            x = positions_samples[frame, :, 0]
            y = positions_samples[frame, :, 1]

            particles_scatter.set_offsets(np.c_[x, y])

            pbar.update()

            return particles_scatter,

        anim = animation.FuncAnimation(fig, update, frames=frame_number, interval=interval, blit=True)

        # Use to_jshtml to convert the animation to a JavaScript HTML video
        html_vid = anim.to_html5_video()

        # Clean up the plot
        plt.close(fig)
        pbar.close()
        # Use IPython.display.HTML to display the animation
        return html_vid
    
# Simulation parameters
N_A = 30 # Number of type A particles
N_B = 30 # Number of type B particles
M_A = 0.025 # Mass of type A particles (kg)
M_B = 0.05 # Mass of type B particles (kg)
R = 0.04 # Radius of the particles (m)
v_0 = 0.5 # Initial velocity of the particles (m/s)
seed = 42 # Random seed for particles's position generation

# Create the simulation
simulation = ParticleSimulation(N_A, N_B, M_A, M_B, R, v_0, seed)

# Energy evolution
T = 100  # Total time for simulation
dt_s = 0.04  # Sampling time step

# Perform the simulation with different dt values
dt_values = [0.004, 0.002, 0.001]
energy_evolution = []

# Run the simulation with the different dt values
for dt_value in dt_values:
    positions_samples, velocities_samples, avg_kinetic_energy_A, avg_kinetic_energy_B, avg_potential_energy_A, avg_potential_energy_B = simulation.evolve(T, dt_value, dt_s)

    # Calculate total energy Etot
    Etot = N_A * (avg_kinetic_energy_A + avg_potential_energy_A) + N_B * (avg_kinetic_energy_B + avg_potential_energy_B)
    energy_evolution.append(Etot)

# Plot energy evolution
time = np.arange(0, T, dt_s)
labels = ['dt = 0.004', 'dt = 0.002', 'dt = 0.001']

for i in range(len(dt_values)):
    plt.plot(time, energy_evolution[i], label=labels[i])

plt.xlabel('Time')
plt.ylabel('Total Energy (Etot)')
plt.legend()
plt.show()
