/* */
package hellothread2;


public class HelloThread2 {

    
    public static void main(String[] args) {
        
        // creo gli oggetti di tipo hello Printer
        
        HelloPrinter pi = new HelloPrinter("Buongiorno agli studenti" + 
                                           "di sistemi");
        HelloPrinter pi2 = new HelloPrinter("Oggi siamo in 56 in classe e fuori");
        HelloPrinter pi3 = new HelloPrinter("La lezione di Sistemi" + 
                                            " e' la piu' bella");
        
        // devo creare thread a partire dagli oggetti HelloPrinter
        
        Thread th1 = new Thread(pi,"printer1");
        Thread th2 = new Thread(pi2,"printer2");
        Thread th3 = new Thread(pi3,"printer3");
        
        // ora faccio partire in parallelo i miei threads
        /*
                  main
                    |
                    |
            ________|________
            |      |    |    |
        main|   th1| th2| th3|
            |      |    |    |
            |      |    |    |
        */
        
        th1.start();
        th2.start();
        th3.start();
        
        // il thread main deve attendere per la terminazione 
        // di tutti i threads figli(th1,th2,th3)
        
        try{
            
            th1.join();
            th2.join();
            th3.join();
        
        }catch(InterruptedException e){                 // non si distinguono i vari errori di interruzione 
            System.out.println("Errore join:" + e);     // è molto informativo per capire l'errore
        }
        
        // annuncio che tutti i threads sono terminati e ora vado a terminare il main
        
        System.out.println("Tutti i threads sono terminati!!!!");
        
        // fine main
        
    }
    
}
