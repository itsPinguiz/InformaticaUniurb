/* */
package hellothread2;

/*
    Classe che servira' costruire threads con il metodo 2: 
    implementazione dell'interfaccia java.leng.Runnable
    il thread stampera' carattere per carattere una stringa
*/
public class HelloPrinter implements Runnable {
    
    // attributo interno stringa da dichiarare
    
    private final String toPrint;
    
    public HelloPrinter(String myString){
    
        this.toPrint = myString;
    
    }
    
    // vado a soddisfare l'interfaccia runnable implementando il metodo run()
    
    @Override
    public void run(){
    
        for(int i = 0; i < this.toPrint.length() ; i++)
            System.out.print(this.toPrint.charAt(i)); // estrae il carattere a posizione i-esima
        System.out.println();
        
        // regola FONDAMENTALE della programmmazione concorrente:
        // annunciare SEMPRE la terminazione del thread
        
        System.out.println("Il Thread termina!!");
        
        // fine della run()
        
    }
    
}
