/* */
package hellothread;


public class HelloThread {

  
    public static void main(String[] args) {
        
        // Questo thread sarà il REGISTA del processo multi thread 
        // avra' il compito di:
        // -1 Creare threads
        // -2 Far partire i threads
        // -3 Controllarne l'esecuzione 
        // -4 Attendere la loro esucuzione
        
        // creo i threads di tipo HelloPrinter
        
        HelloPrinter pi = new HelloPrinter("Buongiorno agli studenti" + 
                                           "di sistemi operativi","Printer1");
        HelloPrinter pi2 = new HelloPrinter("Oggi siamo in 38 in classe e fuori c'è il sole","Printer2");
        HelloPrinter pi3 = new HelloPrinter("La lezione di Sistemi Operativi" + 
                                            " e' la piu' bella","Printer3");
        
        // ora faccio partire in parallelo i miei threads
        /*
                  main
                    |
                    |
            ________|________
            |     |    |    |
        main|   pi| pi2| pi3|
            |     |    |    |
            |     |    |    |
        */
        
        pi.start();
        pi2.start();
        pi3.start();
        
        // il thread main deve attendere per la terminazione 
        // di tutti i threads figli(pi,pi2,pi3)
        
        try{
            
            pi.join();
            pi2.join();
            pi3.join();
        
        }catch(InterruptedException e){                 // non si distinguono i vari errori di interruzione 
            System.out.println("Errore join:" + e);     // è molto informativo per capire l'errore
        }
        
        // annuncio che tutti i threads sono terminati e ora vado a terminare il main
        
        System.out.println("Tutti i threads sono terminati!!!!");
    }
    
}
