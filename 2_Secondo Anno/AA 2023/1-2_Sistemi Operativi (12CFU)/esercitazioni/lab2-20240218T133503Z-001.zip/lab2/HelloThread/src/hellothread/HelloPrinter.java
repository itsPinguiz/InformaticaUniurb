/* */
package hellothread;

/*  Creo un thread con il metodo 1: estendo con la classe java.lang.Thread
    il compito di questo thread sarà stampare a shell una stringa passata 
    al suo costruttore  */

public class HelloPrinter extends Thread { // Eredita tutti gli attributi e personalità di thread
    
    private final String toPrint; // conterrà la stringa da stampare
    
    // costruttore della classe
    
    public HelloPrinter(String myString, String myName){
    
        // invoco il costruttore della classe padre passandogli la stringa da usare come nome di un thread
        super(myName);
        this.toPrint = myString;

    }
    
    // Override del metodo run : Tutto quello che viene eseguido in parallelo cioè come flusso di esecuzione multi-tread
    // deve essere scritto all' interno del metodo run che risiede all'interno della classe Thread
    
    @Override
    public void run(){
        // tutto ciò che scrivo qua viene eseguito come flusso di esecuzione in parallelo a tutti quanti
        // stampo la stringa un carettere alla volta
        
        for(int i = 0; i < this.toPrint.length(); i++)
            System.out.print(this.toPrint.charAt(i)); // estrae il carattere a posizione i-esima
        System.out.println();
        
        // regola FONDAMENTALE della programmmazione concorrente:
        // annunciare SEMPRE la terminazione del thread
        
        System.out.println("Il Thread -"+super.getName()+"- termina!!");
        
        // fine della run()
    }
    // fine della classe
}
