#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

/* inizio codice esempio fork */

int main(void){
	
	pid_t pid;
	printf("Io sono il processo originale con PID %d mio padre ha PID %d\n",getpid(), getppid());
	
	/* vado a creare un nuovo processo identico a me */
	pid = fork();
	printf("Hello world!!\n");

	/* vado a distinguere il codice del padre da quello del figlio */
	if(pid == 0){

		printf("Sono il figlio con PID %d\n",getpid());
		printf("Mio padre a PID %d\n",getppid());
		/*sleep(20);*/
	}
	else if(pid > 0){

		printf("Mio figlio ha PID %d\n",pid);
		wait(NULL);
		printf("Mio figlio è terminato\n");
		/*sleep(20);*/
	}
	else {
		fprintf(stderr,"Errore fork\n"); /**/
		exit(1);
	}
	exit(0);
}

