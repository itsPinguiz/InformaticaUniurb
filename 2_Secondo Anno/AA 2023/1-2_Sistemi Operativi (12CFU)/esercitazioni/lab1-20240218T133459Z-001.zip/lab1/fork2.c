#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main(void){

	pid_t pid;

	int valore_ritorno = 0; /* questa variabile serve a catturare 
				   il valore di processo del figlio */
	
	printf("Io sono il processo originale con PID %d\n",getpid());

	pid = fork();
	/* ora ho due parocessi identici in esecuzione */
	if(pid == 0){
		
		execl("/bin/pstree","pstree","-u","studente", NULL);	/* questo sostituisce il figlio 
						    			con il codice di ls e lo esegue */

	}else if(pid2 == 0){

		excel("/bin/grep","");
	
	}else if(pid > 0 || pid2 > 0){
	
		wait(&valore_ritorno);
		valore_ritorno = valore_ritorno >> 8;/* shift di 8 posizioni */
		/* ora posso stapare il valore di ritorno */
		printf("Il figlio termina con valore %d\n", valore_ritorno);

	}else {
		fprintf(stderr,"Errore fork\n"); /**/
		exit(1);
	}
	exit(0);


}

